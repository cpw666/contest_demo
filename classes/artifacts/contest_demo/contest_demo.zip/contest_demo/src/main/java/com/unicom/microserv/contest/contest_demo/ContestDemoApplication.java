package com.unicom.microserv.contest.contest_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContestDemoApplication.class, args);
	}
}
